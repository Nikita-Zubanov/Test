﻿using Microsoft.AspNetCore.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DevAppTest.Hubs
{
    public class CallbackHub : Hub
    {
        public async Task Compiled(string appPoolName)
        {
            await Clients.All.SendAsync("PoolCompiled", appPoolName);
        }
    }
}
