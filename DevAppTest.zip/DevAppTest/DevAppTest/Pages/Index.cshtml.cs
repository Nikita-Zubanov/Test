﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace DevAppTest.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        [BindProperty]
        public List<IISPool> IISPools { get; set; }

        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
            IISPools = new List<IISPool>
            {
                new IISPool{Name="test", IsChecked = false},
                new IISPool{Name="vl_253", IsChecked = false},
            };
        }

        public void OnGetCompile(string appPoolName)
        {

        }
    }

    public class IISPool
    {
        public string Name { get; set; }
        public bool IsChecked { get; set; }
    }
}
